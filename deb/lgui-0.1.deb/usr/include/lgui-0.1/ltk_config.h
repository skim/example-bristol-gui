#ifndef LTK_CONFIG_H_
#define LTK_CONFIG_H_

#include <gtk/gtk.h>

#define LTK_SWITCH_VISIBLE_ICON_SIZE	GTK_ICON_SIZE_MENU
#define LTK_SWITCH_VISIBLE_STOCK_SHOW	"gtk-go-down"
#define LTK_SWITCH_VISIBLE_STOCK_HIDE	"gtk-go-up"

#endif /* LTK_CONFIG_H_ */

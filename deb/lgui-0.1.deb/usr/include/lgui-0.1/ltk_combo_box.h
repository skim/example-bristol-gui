#ifndef LTK_COMBO_BOX_H_
#define LTK_COMBO_BOX_H_

#include <gtk/gtk.h>
#include "llib.h"

void		ltk_combo_box_fill							(GtkComboBox *combo_box, LValueList *values);
void		ltk_combo_box_connect_value					(GtkComboBox *combo_box, LValue *value);
void		ltk_combo_box_disconnect_value				(GtkComboBox *combo_box, LValue *value);

#endif /* LTK_COMBO_BOX_H_ */

#ifndef LLIB_OPTION_H_
#define LLIB_OPTION_H_

#include "glib.h"
#include "llib_common.h"
#include "llib_value.h"


typedef struct _LOption 	LOption;
typedef struct _LOptionList LOptionList;

typedef void (*LOptionListCallback) (LOptionList *list, LOption *option, gpointer data);

LOption*		l_option_new_from_option		(LOption *source);
LOption*		l_option_new_string				(const char *id, const char *flag);
LOption*		l_option_new_int				(const char *id, const char *flag);
LType			l_option_get_type				(LOption *option);
const char* 	l_option_get_id					(LOption *option);

LOptionList*	l_option_list_new				();
void 			l_option_list_insert_option		(LOptionList *list, LOption *option, LValue *default_value, gboolean copy);
LOption*		l_option_list_get_option		(LOptionList *list, const char *id);
LOption* 		l_option_list_nth_option		(LOptionList *list, int index);
GList*			l_option_list_get_option_ids	(LOptionList *list);
void			l_option_list_set_value			(LOptionList *list, const char *id, LValue *value);
LValue*			l_option_list_get_value			(LOptionList *list, const char *id);
int				l_option_list_length_options	(LOptionList *list);
int 			l_option_list_length_values		(LOptionList *list);
const char* 	l_option_list_render_cli		(LOptionList *list, const char *prefix);

//FIXME: must currently be called BEFORE any values are added!
void			l_option_list_add_value_change_listener (LOptionList *list, LOptionListCallback func, gpointer data);

#endif /* LLIB_OPTION_H_ */

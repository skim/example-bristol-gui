#ifndef LTK_SWITCH_H_
#define LTK_SWITCH_H_

#include "ltk_config.h"
#include "llib_value.h"
#include <gtk/gtk.h>

void ltk_switch_visible_connect			(GtkButton *button, GtkWidget *widget);
void ltk_switch_sensitive_connect		(GtkButton *button, GtkWidget *widget);
void ltk_switch_connect_enable_value	(GtkButton *button, LValue *value);
void ltk_switch_disconnect_enable_value	(GtkButton *button, LValue *value);

#endif /* LTK_SWITCH_H_ */
